function dx = NlFuncGap(dt, x, w, u)
%%[ds,dv,da,df,v,a,f]

ElcMap=[[0;0;0;2222],[298303;0;0;2222]];

xl=x;ul=[w;u];
for k=1:dt/0.05
    xp=NlFunc(0.05, xl, ul, ElcMap);
    xl=xp;
end

dx=xl;
end